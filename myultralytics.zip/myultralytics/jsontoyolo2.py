import os
import json
import numpy as np
from PIL import Image


def get_image_size(image_path):
    """
    获取图像的宽度和高度
    """
    with Image.open(image_path) as img:
        return img.size  # 返回 (width, height)


def convert_json_to_yolo(input_json_path, output_txt_path, img_path):
    """
    将 Labelme 标注的 JSON 文件转换为 YOLO 格式的 TXT 文件
    """
    # 获取图像的宽度和高度
    img_width, img_height = get_image_size(img_path)

    # 读取 JSON 文件
    with open(input_json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    # 获取标注信息
    shapes = data.get('shapes', [])

    # 打开输出的 TXT 文件
    with open(output_txt_path, 'w') as f:
        for shape in shapes:
            label = shape.get('label')  # 获取标注的类别
            points = shape.get('points')  # 获取标注的坐标

            if not points:
                continue  # 如果没有坐标，则跳过

            # 将点转换为 numpy 数组，便于计算最小外接矩形
            points_np = np.array(points)

            # 计算最小外接矩形
            x_min = np.min(points_np[:, 0])
            x_max = np.max(points_np[:, 0])
            y_min = np.min(points_np[:, 1])
            y_max = np.max(points_np[:, 1])

            # 计算矩形框的中心点 (x_center, y_center) 和宽高 (width, height)
            x_center = (x_min + x_max) / 2.0 / img_width
            y_center = (y_min + y_max) / 2.0 / img_height
            width = (x_max - x_min) / img_width
            height = (y_max - y_min) / img_height

            # YOLO 类别通常从 0 开始，这里假设 label 是分类名，如果需要转为数字，可以修改
            # 这里我们假设 'EGC' 对应的类标签是 0（你可以根据需要修改）
            object_class = 0  # 将 'EGC' 映射为 0 类别

            # 写入 YOLO 格式的数据
            f.write(f"{object_class} {x_center} {y_center} {width} {height}\n")

   # print(f"转换完成，YOLO 格式的标注已保存到 {output_txt_path}")


def convert_folder_json_to_yolo(input_folder, img_folder, output_folder):
    """
    将文件夹中的所有 JSON 文件转换为 YOLO 格式的 TXT 文件
    """
    # 如果输出文件夹不存在，则创建
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # 遍历输入文件夹中的所有 JSON 文件
    for filename in os.listdir(input_folder):
        if filename.lower().endswith('.json'):
            input_json_path = os.path.join(input_folder, filename)
            # 图像文件路径假设与 JSON 文件同名，并且为 JPG 格式
            img_path = os.path.join(img_folder, os.path.splitext(filename)[0] + '.jpg')  # 获取同名 JPG 文件
            if not os.path.exists(img_path):
                print(f"警告: 未找到图像文件 {img_path} 对应的 JSON 文件 {filename}")
                continue  # 如果没有找到对应的图像文件，则跳过

            output_txt_filename = os.path.splitext(filename)[0] + '.txt'
            output_txt_path = os.path.join(output_folder, output_txt_filename)

            # 转换每个 JSON 文件
            convert_json_to_yolo(input_json_path, output_txt_path, img_path)

# 设置输入文件夹路径（包含 JSON 文件）和输出文件夹路径（保存 TXT 文件）
input_folder = r'D:\code\ultralytics\data\alldata\第四批\labels'  # 替换为你的 JSON 文件夹路径
img_folder = r'D:\code\ultralytics\data\alldata\第四批\images'  # 替换为你的图像文件夹路径
output_folder = r'D:\code\ultralytics\data\alldata\第四批\labels_yolo'  # 替换为你的输出 TXT 文件夹路径

# 调用转换函数
convert_folder_json_to_yolo(input_folder, img_folder, output_folder)
