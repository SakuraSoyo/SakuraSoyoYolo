from ultralytics import YOLO

#不训练，只看模型结构、参数量、计算量
if __name__ == "__main__":
    # Load a model
    cfg_path = './ultralytics/cfg/models/v8/yolov8-transformer.yaml'
    model = YOLO(cfg_path)
    model._new(cfg_path, task='detect', verbose=True)


