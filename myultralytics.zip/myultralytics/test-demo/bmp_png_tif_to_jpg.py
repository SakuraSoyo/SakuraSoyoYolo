import os
from PIL import Image


def convert_images_to_jpg(input_folder, output_folder):
    # 检查输出文件夹是否存在，如果不存在则创建它
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # 遍历输入文件夹中的所有文件
    for filename in os.listdir(input_folder):
        file_path = os.path.join(input_folder, filename)

        # 只处理图片文件，支持 .jpg, .bmp, .tif 格式
        if filename.lower().endswith(('jpg', 'bmp', 'tif')):
            try:
                # 打开图片
                with Image.open(file_path) as img:
                    # 获取文件的基本名称和扩展名
                    base_name = os.path.splitext(filename)[0]
                    # 设置新的保存路径，将图片保存到输出文件夹，并转换为 .jpg 格式
                    save_path = os.path.join(output_folder, base_name + '.jpg')
                    # 保存为 jpg 格式
                    img.convert('RGB').save(save_path, 'JPEG')
                    #print(f"{filename} 已转换为 {save_path}")
            except Exception as e:
                print(f"无法处理 {filename}: {e}")


# 设置输入文件夹路径（原始图片所在文件夹）和输出文件夹路径（转换后图片保存的文件夹）
input_folder = r'D:\code\ultralytics\data\alldata\第三批早期胃癌已标记（voc）\data'  # 替换为原始图片文件夹路径
output_folder = r'D:\code\ultralytics\data\alldata\第三批早期胃癌已标记（voc）\data\images'  # 替换为目标输出文件夹路径

# 调用函数转换图片格式
convert_images_to_jpg(input_folder, output_folder)
