from ultralytics import YOLO

if __name__ == '__main__':
   # Load a model
   model = YOLO(r'yolov8-transformer.yaml',task='detect', verbose=True) # verbose print the model,不用预训练权重
   # model = YOLO(r'yolov8-transformer.yaml').load("yolov8n.pt") # 使用预训练权重

   model.train(
       data=r'D:\code\ultralytics\data\fall.yaml',
       epochs=300, #训练轮数
       patience=50, #等待提前停止训练没有明显改善的纪元
       batch=32,
       imgsz=640,
       save=True,
       save_period=-1, #Save checkpoint every x epochs(disabled if < 1)
       cache=False,
       device='',    #(int | str | list, optional) device to run on, i.e. cuda device=0 or device=0,1,2,3 or device=cpu
       workers=8,  #number of worker threads for data loading
       project=r'D:\code\ultralytics\runs\train',
       name='exp3', #(str, optional)experiment name, results saved to 'project/name' directory
       exist_ok=False, #(bool)whether to overwrite existing experiment
       pretrained=True, #(bool\ str)whether to use a pretrained model (bool) or a model to load weights from (str)
       optimizer='SGD', #(str)optimizer to use, choices=[SGD, Adam, Adamax, AdamW, NAdam, RAdam, RMSProp, auto]
       verbose =True,
       seed= 0,
       deterministic=True, #(bool)whether to enable deterministic mode
       single_cls=False, #(bool) train muti-class data as singel-class
       rect=False, #(bool) rectangular training if mode='train' or rectangular validation if mode='val'
       cos_lr=False, #(bool) use cosine learning rate scheduler
       close_mosaic=0, #(int)disable mosaic augmentation for final epochs
       resume=False, #(bool)resume training from last checkpoint
       amp=True, #(bool)Automatic mixed precision to train on (default is 1.0, all imges in train set)
       fraction=1.0, #(float) dataset fraction to train on(default is 1.0, all images in train set)
       profile=False, #(bool) 在训练期间为记录器启用onnx和tensorRT速度
       freeze=None, #(int \ list)在训练期间冻结前n层
       #分割
       overlap_mask=True, #(bool)训练期间是否重叠掩码
       mask_ratio=4, #(int) 掩码降采样比列
       #分类
       dropout=0.0,
       #超参数
       lr0=0.01,  # (float) 初始学习率（例如，SGD=1E-2，Adam=1E-3）
       lrf=0.01,  # (float) 最终学习率（lr0 * lrf）
       momentum=0.937,  # (float) SGD动量/Adam beta1
       weight_decay=0.0005,  # (float) 优化器权重衰减 5e-4
       warmup_epochs=3.0,  # (float) 预热周期（分数可用）
       warmup_momentum=0.8,  # (float) 预热初始动量
       warmup_bias_lr=0.1,  # (float) 预热初始偏置学习率
       box=7.5,  # (float) 盒损失增益
       cls=0.5,  # (float) 类别损失增益（与像素比例）
       dfl=1.5,  # (float) dfl损失增益
       pose=12.0,  # (float) 姿势损失增益
       kobj=1.0,  # (float) 关键点对象损失增益
       label_smoothing=0.0,  # (float) 标签平滑（分数）
       nbs=64,  # (int) 名义批量大小
       hsv_h=0.015,  # (float) 图像HSV-Hue增强（分数）
       hsv_s=0.7,  # (float) 图像HSV-Saturation增强（分数）
       hsv_v=0.4,  # (float) 图像HSV-Value增强（分数）
       degrees=0.0,  # (float) 图像旋转（+/- deg）
       translate=0.1,  # (float) 图像平移（+/- 分数）
       scale=0.5,  # (float) 图像缩放（+/- 增益）
       shear=0.0,  # (float) 图像剪切（+/- deg）
       perspective=0.0,  # (float) 图像透视（+/- 分数），范围为0-0.001
       flipud=0.0,  # (float) 图像上下翻转（概率）
       fliplr=0.5,  # (float) 图像左右翻转（概率）
       mosaic=1.0,  # (float) 图像马赛克（概率）
       mixup=0.0,  # (float) 图像混合（概率）
       copy_paste=0.0,  # (float) 分割复制-粘贴（概率）
   )

