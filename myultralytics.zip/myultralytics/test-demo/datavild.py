import os
import json

def check_json_and_image_files(folder_path):
    # 获取文件夹中的所有 JSON 文件
    json_files = [f for f in os.listdir(folder_path) if f.endswith('.json')]
    missing_images = []

    for json_file in json_files:
        # 获取 JSON 文件的文件名（不包含扩展名）
        base_name = os.path.splitext(json_file)[0]
        bmp_image_path = os.path.join(folder_path, base_name + '.jpg')

        # 检查是否存在对应的 BMP 图像文件
        if not os.path.exists(bmp_image_path):
            missing_images.append(json_file)

    # 打印没有对应图片的 JSON 文件名
    if missing_images:
        print("以下 JSON 文件没有对应的 BMP 图片:")
        for missing_file in missing_images:
            print(missing_file)
    else:
        print("所有 JSON 文件都有对应的 BMP 图片。")

    # 设置文件夹路径


folder_path = r'D:\code\ultralytics\data\alldata\第四批'  # 替换为实际文件夹路径

# 调用函数检查 JSON 文件和对应的 BMP 图片
check_json_and_image_files(folder_path)
