from ultralytics import YOLO

if __name__ == '__main__':
    # Load Model
    model=YOLO(r'yolov8.pt')
    model.predictor(
        source=r'ultralytics/asssets/bus.jpg',
        save=True,
        val=True,
        imgsz=640,
        conf=0.25,
        iou=0.45, #非极大抑制值（NMS）的交并比（Iou）
        show=False,
        project='runs/predict', #name
        name='exp',
        save_txt=False,
        save_conf=True,
        save_crop=False,
        show_labels=True,
        show_conf=True,
        vid_stride=1,
        line_width=3,
        visualize=False,
        augment=False,
        agnostic_nms=False,
        retina_masks=False,
        boses=True,
    )