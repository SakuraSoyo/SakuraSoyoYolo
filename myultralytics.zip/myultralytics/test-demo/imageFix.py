import os
from PIL import Image
import numpy as np

def remove_black_borders(image_path, output_path):
    # 打开图片
    img = Image.open(image_path)
    img = img.convert('RGB')  # 转换为RGB模式，如果是灰度图或其他模式会出错

    # 将图片转换为 NumPy 数组
    img_array = np.array(img)

    # 定义黑色的阈值，这里假设黑色为 (0, 0, 0)
    # 如果背景是接近黑色，可以设置为更大的阈值范围
    threshold = 10

    # 查找非黑色的区域
    non_black_pixels = np.all(img_array > threshold, axis=-1)

    # 获取非黑色区域的边界框
    rows = np.any(non_black_pixels, axis=1)
    cols = np.any(non_black_pixels, axis=0)

    # 计算裁剪区域的边界
    top, bottom = np.argmax(rows), len(rows) - np.argmax(rows[::-1])
    left, right = np.argmax(cols), len(cols) - np.argmax(cols[::-1])

    # 裁剪图片
    cropped_img = img.crop((left, top, right, bottom))

    # 保存裁剪后的图片
    cropped_img.save(output_path)
   # print(f"黑边已去除，裁剪后的图片已保存为 {output_path}")

def process_images_in_folder(input_folder, output_folder):
    # 检查输出文件夹是否存在，如果不存在则创建它
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # 遍历输入文件夹中的所有文件
    for filename in os.listdir(input_folder):
        file_path = os.path.join(input_folder, filename)

        # 只处理图片文件，支持 jpg, bmp, tif 格式
        if filename.lower().endswith(('jpg', 'bmp', 'tif')):
            output_path = os.path.join(output_folder, filename)
            try:
                # 调用去除黑边的函数
                remove_black_borders(file_path, output_path)
            except Exception as e:
                print(f"无法处理 {filename}: {e}")

# 设置输入文件夹路径（原始图片文件夹路径）和输出文件夹路径（裁剪后的图片文件夹路径）
input_folder = r'D:\code\ultralytics\data\alldata\2022胃镜分类_第一批已标注（voc）\data\images'  # 替换为原始图像文件夹路径
output_folder = r'D:\code\ultralytics\data\alldata\2022胃镜分类_第一批已标注（voc）\images'  # 替换为目标文件夹路径

# 调用函数处理文件夹中的所有图片
process_images_in_folder(input_folder, output_folder)
