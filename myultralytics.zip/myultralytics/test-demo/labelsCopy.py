import os
import shutil

def copy_json_files(input_folder, output_folder):
    # 检查输出文件夹是否存在，如果不存在则创建它
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # 遍历输入文件夹中的所有文件
    for filename in os.listdir(input_folder):
        file_path = os.path.join(input_folder, filename)

        # 只处理 .json 文件
        if filename.lower().endswith('.json'):
            try:
                # 构造目标文件的路径
                destination_path = os.path.join(output_folder, filename)
                # 复制文件到目标文件夹
                shutil.copy(file_path, destination_path)
               # print(f"{filename} 已复制到 {destination_path}")
            except Exception as e:
                print(f"无法复制 {filename}: {e}")

# 设置输入文件夹路径（原始 JSON 文件夹路径）和输出文件夹路径（目标文件夹路径）
input_folder = r'D:\code\ultralytics\data\alldata\第四批'  # 替换为原始 JSON 文件夹路径
output_folder = r'D:\code\ultralytics\data\alldata\第四批\labels'  # 替换为目标文件夹路径

# 调用函数复制 JSON 文件
copy_json_files(input_folder, output_folder)
