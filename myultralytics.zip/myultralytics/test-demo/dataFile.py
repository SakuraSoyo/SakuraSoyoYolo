import os
import json


def update_label_in_json_files(folder_path):
    # 遍历文件夹中的所有文件
    for filename in os.listdir(folder_path):
        # 判断是否是JSON文件
        if filename.endswith('.json'):
            file_path = os.path.join(folder_path, filename)
            try:
                # 打开并读取JSON文件
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)

                # 检查并修改"label": "1"
                for shape in data.get('shapes', []):
                    if shape.get('label') == "1":
                        shape['label'] = "EGC"

                # 保存修改后的文件
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=4)

                #print(f"文件 {filename} 更新成功")
            except Exception as e:
                print(f"处理文件 {filename} 时出错: {e}")


# 设置文件夹路径
folder_path = r'D:\code\ultralytics\data\alldata\第三批胃早癌数据（已标注label为1）\3'  # 修改为实际文件夹路径

# 调用函数更新标签
update_label_in_json_files(folder_path)
