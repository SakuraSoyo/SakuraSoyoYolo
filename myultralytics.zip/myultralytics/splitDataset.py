import os
import random

trainval_percent = 0.9
train_percent = 0.9
json_filepath = 'D:/code/ultralytics/data/Annotations'
txtsavepath = 'D:/code/ultralytics/data/ImageSets'
total_json = os.listdir(json_filepath)

num = len(total_json)
list = range(num)
tv = int(num * trainval_percent)
tr = int(tv * train_percent)
trainval = random.sample(list, tv)
train = random.sample(trainval, tr)

ftrainval = open('D:/code/ultralytics/data/ImageSets/trainval.txt', 'w')
ftest = open('D:/code/ultralytics/data/ImageSets/test.txt', 'w')
ftrain = open('D:/code/ultralytics/data/ImageSets/train.txt', 'w')
fval = open('D:/code/ultralytics/data/ImageSets/val.txt', 'w')

for i in list:
    name = total_json[i][:-4] + '\n'
    if i in trainval:
        ftrainval.write(name)
        if i in train:
            ftrain.write(name)
        else:
            fval.write(name)
    else:
        ftest.write(name)

ftrainval.close()
ftrain.close()
fval.close()
ftest.close()
